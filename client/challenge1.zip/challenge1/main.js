// A restuarnt adds to the original cost of any bill:
// 8 % tax 
// 20 % tip
// write a function called billTotal that takes the bill cost as an input and returns the total bill amount (including the tax and the tips) as an output

function billTotal(subtotal) {
 // your code is here
}

//write a function called animalNoise that takes two arguments, the animal name and its emotion, and returns 
// a string of that animal sound according to its emotion, note: No limits for the way you would like to represent the sound of an animal.
// consider at least three animals with two emotions each.
// ex : animalNoise('cat', 'sad')  // ===> 'meawww'

function animalNoise(animal,emotion) {
  // your code is here
}

//write a function called factorial , 
// that takes a number as an input and returns the factorail of that number as an output (using recursion).
// factorial(3); // => 3 * 2 * 1 => 6 
// factorial(4); // => 4 * 3 * 2 * 1 => 24 
// factorial(5); // => 5 * 4 * 3 * 2 * 1 => 120

function factorial(n) {
   //your code is here
}


// write a function called addOne that takes an array of numbers as an input, and returns a new array with all the array elements incremented by one as an output
// Note : solve this question using while loop 
// addOne( [1,2,3,4] ) ==> [2,3,4,5]
// addOne( [3,6,9] ) ==> [4,7,10]

function addOne(array){
 // your code is here
}

/*

  Use JS to represent 2 people in your family. Please include the below:
  - Name
  - Relationship to you
  - Age
  - Occupation

*/

var bucketOfSloths = [
  {name: {first: "Furry", middle: "Danger", last: "Assassin"}, age: 2},
  {name: {first: "Slow", last: "Pumpkin"}, age: 3},
  {name: {first: "Bullet", middle: "Proof", last: "Sloth"}, age: 4},
  {name: {first: "Boos", middle: "Boos", last: "Bun"}, age: 5},
  {name: {first: "Jungle", last: "Fuzz"}, age: 2}
];

// write a function called longestName, that takes an array as an input (in this case its bucketOfSloths array)
// and returns the sloth with the longest name in that array
// Note that: the longest name is not only the first name, its first, middle and last name compined.
 
function longestName(bucketOfSloths) {
  //your code is here 
}